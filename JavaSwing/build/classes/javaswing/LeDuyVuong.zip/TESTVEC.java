/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaswing;

/**
 *
 * @author Hi-XV
 */
public class TESTVEC extends lopJava{
    static String name;
    public static void main(String[] args) {
        lopJava test = new lopJava();
        test.add("Le Duy Vuong", 10, "23211210077");
        test.add("Lung Linh ", 5, "3412421124124");
        test.inDS();
        test.del("Lung Linh ");
        test.inDS();
        test.delSvCuoi(ds.size()-1);
        test.inDS();
    }
}
