/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kiemtra;

import java.awt.BorderLayout;
import java.awt.Event;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

/**
 *
 * @author Hi-XV
 */
public class GUI extends Frame implements ActionListener {

    private JTextField txtName, txtGender, txtAddress, txtEmployeeID, txtlbAllo, txtRate, txtNumberWorking, txtYearOfExp;
    private JButton btnAdd, btnDel;
    private JLabel lbName, lbGender, lbAddress, lbEmployeeID, lbAllo, lbRate, lbNumberWorking, lbYearOfExp;
    private JFrame gd;

    private JRadioButton radioPay;
    private JRadioButton radioCons;
    private final Staff staff;
    private JPanel pn1;

    public GUI() {
        createGD();
        staff = new Staff();
    }

    public void createGD() {

        gd = new JFrame();

        gd.setLocationRelativeTo(null);
        gd.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        gd.setVisible(true);
        pn1 = new JPanel();
        pn1.setLayout(new GridLayout(10, 2));
        txtEmployeeID = new JTextField(10);
        lbEmployeeID = new JLabel("EmployeeID");
        pn1.add(lbEmployeeID);
        pn1.add(txtEmployeeID);

        txtName = new JTextField(10);
        lbName = new JLabel("Name");
        pn1.add(lbName);
        pn1.add(txtName);

        txtGender = new JTextField(10);
        lbGender = new JLabel("Gender");
        pn1.add(lbGender);
        pn1.add(txtGender);

        txtAddress = new JTextField(10);
        lbAddress = new JLabel("Address");
        pn1.add(lbAddress);
        pn1.add(txtAddress);

        txtYearOfExp = new JTextField(10);
        lbYearOfExp = new JLabel("YearOfExp");
        pn1.add(lbYearOfExp);
        pn1.add(txtYearOfExp);

        txtlbAllo = new JTextField(10);
        lbAllo = new JLabel("Allowance");
        pn1.add(lbAllo);
        pn1.add(txtlbAllo);

        radioPay = new JRadioButton("PayrollStaff");
        radioCons = new JRadioButton("ConstractStaff");
        pn1.add(radioPay);
        pn1.add(radioCons);

        txtRate = new JTextField(10);
        lbRate = new JLabel("Rate");
        pn1.add(lbRate);
        pn1.add(txtRate);

        txtNumberWorking = new JTextField(10);
        lbNumberWorking = new JLabel("NumberWorking");
        pn1.add(lbNumberWorking);
        pn1.add(txtNumberWorking);

        btnAdd = new JButton("Them");
        btnDel = new JButton("Xoa");
        btnAdd.addActionListener(this);
        btnDel.addActionListener(this);
        pn1.add(btnAdd);
        pn1.add(btnDel);

        gd.add(pn1);
        gd.pack();
    }

    public void clear() {
        txtName.setText("");
        txtGender.setText("");
        txtEmployeeID.setText("");
        txtAddress.setText("");
        txtlbAllo.setText("");
        txtNumberWorking.setText("");
        txtYearOfExp.setText("");
        txtRate.setText("");
    }
    public void btnAddActiongListener(ActionEvent e) {
        Employee employee;
        String employeeID = txtEmployeeID.getText();
        String name = txtName.getText();
        String gender = txtGender.getText();
        String address = txtAddress.getText();
        double allowance = Double.parseDouble(txtlbAllo.getText());
            if (radioPay.isSelected()) {
                double rate;
                rate = Double.parseDouble(txtRate.getText());
                employee = new PayrollStaff(employeeID, rate, name, gender, address, allowance);
                radioPay.setSelected(false);
                clear();
            } else {
                int numberofworkingdays = Integer.parseInt(txtNumberWorking.getText());
                int yearOfExp = Integer.parseInt(txtYearOfExp.getText());
                employee = new ConstractStaff(employeeID, numberofworkingdays, name, gender, address, yearOfExp, allowance);
                radioCons.setSelected(false);
                clear();
            }
            this.staff.Add(employee);
    }
    public void btnDelActionListener(ActionEvent e) {
        String employid = txtEmployeeID.getText();
        this.staff.Delete(employid);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        String tmp = ((JButton) e.getSource()).getText();
        if (tmp.equals("Them")) {
            btnAddActiongListener(e);
        }
        if (tmp.equals("Xoa")) {
            btnDelActionListener(e);
        }
    }

}
